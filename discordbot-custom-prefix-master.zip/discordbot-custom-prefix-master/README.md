## Custom Prefix
  - **Take Note: This is not Recomended for bots in Huge Servers, JSON Files can get Corrupt.**  

### Installing
  - **On your Terminal, do `npm i --save discord.js fs` ( That will install Discord.js and fs )**  
 
### What to Do
  - **Add your Bot Token on the config.json File and you can set your own Prefix there**  
  - **[ Optional But if your Bot is in Guilds, do this > ] If your bot is in Guilds, please add the Guild id there and a prefix**  
  
### Credits
  **Tbh, none helped me except me.**  
  My Username: **Boujee#9310**  
  My Server: **https://discord.gg/xTwAJNu**

### Questions
  **Q**: Ain't fs an API of Node?  
  **A**: It is, and you don't need to Install, but it will give you the Experimental one, so i suggest, install it.
